﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void calculadoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //declarar e instanciar um objeto do tipo frmCalculadora
            frmCalculadora2 objCalculadora = new frmCalculadora2();
            objCalculadora.Show();
        }

        private void médiaAritméticaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMediaAritimetica objMediaAritimetica = new frmMediaAritimetica();
            objMediaAritimetica.Show();
        }

        private void calculadora2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCalculadora2 objCalculadora2 = new frmCalculadora2();
            objCalculadora2.Show();
        }
    }
}
