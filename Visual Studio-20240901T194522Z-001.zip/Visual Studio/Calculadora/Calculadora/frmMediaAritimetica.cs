﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class frmMediaAritimetica : Form
    {
        public frmMediaAritimetica()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //var
            double nota1, nota2, media;
            //entrada
            nota1 = double.Parse(txtNota1.Text);
            nota2 = double.Parse(txtNota2.Text);
            //Processamento
            media = (nota1 + nota2) / 2;
            //saída
            lblMedia.Text = media.ToString();
            //regra situação
            //Se média for > =  7 escreve aprovado, senao escreve exame
            if (media >= 7)
            {
                lblSituacao.Text = "Aprovado";
            }
            else
            {
                lblSituacao.Text = "Exame";
            }
        }
    }
}
