﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace calc2
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            //var
            double n1, n2, resultado;
            //entrada
            n1 = double.Parse(txtNumero1.Text);
            n2 = double.Parse(txtNumero2.Text);
            //processamento
            resultado = n1 + n2;
            //saída
            lblResultado.Text = resultado.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            //var
            double n1, n2, resultado;
            //entrada
            n1 = double.Parse(txtNumero1.Text);
            n2 = double.Parse(txtNumero2.Text);
            //processamento
            resultado = n1 - n2;
            //saída
            lblResultado.Text = resultado.ToString();
        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void frmCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //var
            double n1, n2, resultado;
            //entrada
            n1 = double.Parse(txtNumero1.Text);
            n2 = double.Parse(txtNumero2.Text);
            //processamento
            resultado = n1 + n2;
            //saída
            lblResultado.Text = resultado.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //var
            double n1, n2, resultado;
            //entrada
            n1 = double.Parse(txtNumero1.Text);
            n2 = double.Parse(txtNumero2.Text);
            //processamento
            resultado = n1 / n2;
            //saída
            lblResultado.Text = resultado.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //var
            double n1, n2, resultado;
            //entrada
            n1 = double.Parse(txtNumero1.Text);
            n2 = double.Parse(txtNumero2.Text);
            //processamento
            resultado = n1 * n2;
            //saída
            lblResultado.Text = resultado.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //var
            double n1, n2, resultado;
            //entrada
            n1 = double.Parse(txtNumero1.Text);
            n2 = double.Parse(txtNumero2.Text);
            //processamento
            resultado = n1 - n2;
            //saída
            lblResultado.Text = resultado.ToString();
        }
    }
}
