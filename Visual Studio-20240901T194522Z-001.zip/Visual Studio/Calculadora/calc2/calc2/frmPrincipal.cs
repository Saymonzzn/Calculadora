﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace calc2
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void calculadoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //declarar e instanciar um objeto do tipo frmCalculadora
            frmCalculadora objCalculadora = new frmCalculadora();
            objCalculadora.Show();
        }

        private void médiaAritméticaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            frmMediaAritimetica objMediaAritimetica = new frmMediaAritimetica();
            objMediaAritimetica.Show();
        }

        private void algoritmosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
