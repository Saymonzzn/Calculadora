﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace calc2
{
    public partial class frmMediaAritimetica : Form
    {
        public frmMediaAritimetica()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //var
            double nota1, nota2, media;
            //entrada
            nota1 = double.Parse(txtNota1.Text);
            nota2 = double.Parse(txtNota2.Text);
            //Processamento
            media = (nota1 + nota2) / 2;
            //saída
            lblResultado.Text = media.ToString();
            //regra situação
            //Se média for > =  7 escreve aprovado, senao escreve exame
            if (media >= 7)
            {
                lblSituacao.Text = "Aprovado";
            }
            else
            {
                lblSituacao.Text = "Exame";    
            }
        }

        private void txtNota1_TextChanged(object sender, EventArgs e)
        {
           
                
        }

        private void lblSituacao_Click(object sender, EventArgs e)
        {

        }

        private void lblMedia_Click(object sender, EventArgs e)
        {

        }
    }
}
